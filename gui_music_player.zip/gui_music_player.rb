require 'rubygems'
require 'gosu'

## Icons
# Icons made by "Those Icons" from www.flaticon.com
# https://www.flaticon.com/authors/those-icons


TOP_COLOR = Gosu::Color.new(0xFF1EB1FA)
BOTTOM_COLOR = Gosu::Color.new(0xFF1D4DB5)
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 475
TRACKX = 500
PLAY_BUTTON = "images/play.png"
STOP_BUTTON = "images/stop.png"
PAUSE_BUTTON = "images/pause.png"
NEXT_BUTTON = "images/next.png"

module ZOrder
  BACKGROUND, PLAYER, UI = *0..2
end

module Genre
	POP, CLASSIC, JAZZ, ROCK = *1..4
	NAME = ['Null', 'Pop', 'Classic', 'Jazz', 'Rock']
  end


class ArtWork
	attr_accessor :bmp
	def initialize (file)
		@bmp = Gosu::Image.new(file)
	end
end

  
# Track class
class Track
	attr_accessor :name, :location
	def initialize (name, location)
		@name = name
		@location = location
	end
end
  

class Album
	attr_accessor :title, :artist, :genre, :art, :tracks
	def initialize (title, artist, genre, art, tracks)
		@title = title
		@artist = artist
		@genre = genre
		@art = art
		@tracks = tracks
	end
end
  
  
# Reads in and returns a single track from the given file
def read_track (music_file)
	name = music_file.gets.chomp
	location = music_file.gets.chomp
	track = Track.new(name, location)
	return track
end
  
  
# Returns an array of tracks read from the given file
def read_tracks (music_file)
	tracks = Array.new()
	number_of_tracks = music_file.gets().to_i
	i = 0
	while i < number_of_tracks
		track = read_track(music_file)
		tracks << track
		i += 1
	end
	return tracks
end
  
  
# Reads in and returns a single album from the given file, with all its tracks
def read_album(music_file)
	album_title = music_file.gets.chomp
	album_artist = music_file.gets.chomp
	album_genre = music_file.gets.to_i
	album_art = ArtWork.new(music_file.gets.chomp)
	tracks = read_tracks(music_file)
	album = Album.new(album_title, album_artist, album_genre, album_art, tracks)
	return album
end
  
  
# Reads in and returns multiple albums from the given file, with all its tracks
def read_albums(music_file)
	number_of_albums = music_file.gets().to_i

	albums = Array.new()
	i = 0
	while i < number_of_albums
		album = read_album(music_file)
		albums << album
		i += 1
	end

	return albums
end
  
# Takes a file name as string and read the data from it
def read_albums_file(file_name)
	if(File.exists?(file_name))
		music_file = File.new(file_name, "r")
		albums = read_albums(music_file)
		music_file.close()
		return albums
	else
		puts "Cannot read file!"
	end
end

# Takes a single track and prints it to the terminal
def print_track(track)
    puts('Track title is: ' + track.name)
    puts('Track file location is: ' + track.location)
end

# Takes an array of tracks and prints them to the terminal
def print_tracks(tracks)
    for track in tracks
        print_track(track)
    end
end


# Takes a single album and prints it to the terminal along with all its tracks
def print_album(album)
    puts "Title: #{album.title}"
    puts "By: #{album.artist}"
    puts "Genre: #{Genre::NAME[album.genre]}"
    # puts "Art: #{album.art}"
    print_tracks(album.tracks)
end

def print_albums(albums)
    i = 0
    while i < albums.length
        print_album(albums[i])
        i += 1
    end
end

def draw_image_scaled(image, x, y, width, height, z)
	scale_x = (0.0 + width) / image.width
	scale_y = (0.0 + height) / image.height
	image.draw(x, y, z, scale_x, scale_y)
end

def draw_albums(albums)
	y = 25
	i = 0
	while y <= 250
		x = 25
		while x <= 250
			draw_image_scaled(albums[i].art.bmp, x, y, 200, 200, ZOrder::PLAYER)
			x += 225
			i += 1
		end
		y += 225
	end
end

def draw_track(title, ypos, colour)
	font = Gosu::Font.new(20)
	font.draw(title, TRACKX, ypos, ZOrder::PLAYER, 1.0, 1.0, colour)
end

def draw_tracks(tracks, selected)
	i = 0
	y = 25
	while i < tracks.length
		colour = Gosu::Color::WHITE
		if selected == i 
			colour = Gosu::Color::RED
		end
		draw_track("#{i + 1} - #{tracks[i].name}", y, colour)
		y += 25
		i += 1
	end
end

def draw_controls(play, pause, stop, next_button)
	draw_image_scaled(play, 500, 400, 50, 50, ZOrder::UI)
	draw_image_scaled(pause, 575, 400, 50, 50, ZOrder::UI)
	draw_image_scaled(stop, 650, 400, 50, 50, ZOrder::UI)
	draw_image_scaled(next_button, 725, 400, 50, 50, ZOrder::UI)
end

def draw_background
	draw_quad(0, 0, Gosu::Color::GRAY, SCREEN_WIDTH, 0, Gosu::Color::GRAY, 0, SCREEN_HEIGHT, Gosu::Color::GRAY, SCREEN_WIDTH, SCREEN_HEIGHT, Gosu::Color::GRAY, ZOrder::BACKGROUND)
end

def control_clicked()
	selected = nil
	found = false
	x = 500
	i = 0
	while x <= 725 && !found
		if area_clicked(x, 400, x + 50, 450)
			found = true
			selected = i
		end
		x += 75
		i += 1
	end
	return selected
end

def track_clicked()
	selected = nil
	found = false
	y = 25
	i = 0
	while y <= (25 + (15 * 25)) && !found
		if area_clicked(TRACKX, y, TRACKX + 200, y + 20)
			found = true
			selected = i
		end
		y += 25
		i += 1
	end
	return selected
end

def album_clicked()
	selected = nil
	found = false
	y = 25
	i = 0
	while y <= 250 && !found
		x = 25
		while x <= 250 && !found
			if area_clicked(x, y, x + 200, y + 200)
				found = true
				selected = i
			end
			x += 225
			i += 1
		end
		y += 225
	end
	return selected
end

def area_clicked(leftX, topY, rightX, bottomY)
	clicked = false
	if (mouse_x > leftX && mouse_x < rightX) && (mouse_y > topY && mouse_y < bottomY)
		clicked = true
	end
	return clicked
end

def play_track(track, album)
	if track >= 0 && track <= album.tracks.length 
		@song = Gosu::Song.new(album.tracks[track].location)
		@song.play(false)
	end
end

class MusicPlayerMain < Gosu::Window

	def initialize
	    super SCREEN_WIDTH, SCREEN_HEIGHT
	    self.caption = "Music Player"
		@albums = read_albums_file("albums.txt")
		@play_button = Gosu::Image.new(PLAY_BUTTON)
		@pause_button = Gosu::Image.new(PAUSE_BUTTON)
		@stop_button = Gosu::Image.new(STOP_BUTTON)
		@next_button = Gosu::Image.new(NEXT_BUTTON)
		@selected_album = nil
		@selected_track = nil
		# print_albums(@albums)
	end

	def update
		if @selected_track && !@stopped && !@song.paused? && !@song.playing?
			if @selected_track < @albums[@selected_album].tracks.length - 1
				@selected_track += 1
				play_track(@selected_track, @albums[@selected_album])
			end
		end
	end


	def draw
		draw_background
		draw_controls(@play_button, @pause_button, @stop_button, @next_button)
		draw_albums(@albums)
		if @selected_album
			draw_tracks(@albums[@selected_album].tracks, @selected_track)
		end
	end

 	def needs_cursor?; true; end

	def button_down(id)
		case id
	    when Gosu::MsLeft
			clicked = album_clicked
			if clicked
				@selected_album = clicked
				@selected_track = nil
			end
			if @selected_album
				clicked = track_clicked
				if clicked && clicked < @albums[@selected_album].tracks.length
					@selected_track = clicked
					play_track(@selected_track, @albums[@selected_album])
				end
			end
			clicked = control_clicked
			player_controls(clicked)
		end
	end

	def player_controls(clicked)
		case clicked
		when 0
			if @selected_album
				if @selected_track
					@song.play(false)
				else
					@selected_track = 0
					play_track(@selected_track, @albums[@selected_album])
				end
			end
		when 1
			if @song && @song.playing?
				@song.pause()
			end
		when 2
			if @song && @song.playing?
				@song.stop()
				@stopped = true
			end
		when 3
			if @selected_track
				if @selected_track < @albums[@selected_album].tracks.length - 1
					@selected_track += 1
				else
					@selected_track = 0
				end
				play_track(@selected_track, @albums[@selected_album])
			end
		end
	end
end

# Show is a method that loops through update and draw

MusicPlayerMain.new.show if __FILE__ == $0
